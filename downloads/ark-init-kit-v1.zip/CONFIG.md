# ARK 配置手册

`~/ark-system/config.sh` 的完整配置说明。

---

## 核心配置项

### FEISHU_WEBHOOK（必填）

飞书机器人 Webhook 地址。获取方式：

1. 打开飞书 → 群聊 → 设置 → 群机器人 → 添加机器人 → 自定义机器人
2. 安全设置选「自定义关键词」，填入 `ARK`
3. 复制 Webhook URL

```bash
FEISHU_WEBHOOK="https://open.feishu.cn/open-apis/bot/v2/hook/xxxxxxxxxx"
```

测试：

```bash
source ~/ark-system/config.sh
curl -X POST "$FEISHU_WEBHOOK" \
  -H "Content-Type: application/json" \
  -d '{"msg_type":"text","content":{"text":"ARK 配置测试"}}'
```

### HEARTBEAT_CRON

心跳检测的 cron 表达式。

```bash
HEARTBEAT_CRON="*/30 * * * *"   # 每30分钟（默认）
HEARTBEAT_CRON="*/5 * * * *"    # 每5分钟（高频）
HEARTBEAT_CRON="0 * * * *"      # 每小时整点
HEARTBEAT_CRON="0 */2 * * *"    # 每2小时
```

### LOG_RETENTION_DAYS

日志保留天数，超过自动清理。

```bash
LOG_RETENTION_DAYS=30   # 保留30天（默认）
```

### SYSTEM_NAME

用于通知消息前缀，方便区分多台机器。

```bash
SYSTEM_NAME="ARK"          # 默认
SYSTEM_NAME="ARK-阿里云"    # 多机器时区分
SYSTEM_NAME="ARK-MacBook"  # 本地开发机
```

---

## Cron 表达式速查

```
┌─────── 分钟 (0-59)
│ ┌──────── 小时 (0-23)
│ │ ┌──────── 日 (1-31)
│ │ │ ┌──────── 月 (1-12)
│ │ │ │ ┌──────── 星期 (0-7, 0=周日)
│ │ │ │ │
* * * * *
```

| 场景 | 表达式 |
|------|--------|
| 每5分钟 | `*/5 * * * *` |
| 每10分钟 | `*/10 * * * *` |
| 每30分钟 | `*/30 * * * *` |
| 每小时整点 | `0 * * * *` |
| 每2小时 | `0 */2 * * *` |
| 每天早上9点 | `0 9 * * *` |
| 每天22点 | `0 22 * * *` |
| 每周一9点 | `0 9 * * 1` |
| 每月1号9点 | `0 9 1 * *` |

---

## 目录结构

```
~/ark-system/
├── config.sh          # 配置文件
├── cron.d/            # 定时任务脚本目录
│   └── heartbeat.sh   # 心跳检测
├── logs/              # 日志目录
│   └── system.log     # 系统日志
├── agents/            # Agent 提示词存放
│   ├── cruiser.md     # 每日巡航
│   ├── collector.md   # 内容采集
│   └── analyst.md     # 数据分析
└── scripts/           # 自定义脚本
```

---

## 日志说明

### 日志文件

| 文件 | 内容 |
|------|------|
| `logs/system.log` | 所有心跳记录和系统事件 |

### 日志格式

```
[2026-07-08 22:30:00] 心跳检测: 正常
[2026-07-08 22:30:01] 飞书通知已发送
[2026-07-08 23:00:00] 心跳检测: 告警
```

### 查看日志

```bash
# 实时跟踪
tail -f ~/ark-system/logs/system.log

# 最近50条
tail -50 ~/ark-system/logs/system.log

# 搜索告警
grep "告警" ~/ark-system/logs/system.log

# 今日日志
grep "$(date +%Y-%m-%d)" ~/ark-system/logs/system.log
```

### 日志清理

```bash
# 手动清理30天前的日志
find ~/ark-system/logs/ -name "*.log" -mtime +30 -delete

# 或添加 cron 自动清理
0 3 * * * find ~/ark-system/logs/ -name "*.log" -mtime +30 -delete
```

---

## 添加自定义定时任务

1. 在 `~/ark-system/cron.d/` 下创建脚本：

```bash
#!/usr/bin/env bash
# my-task.sh
source ~/ark-system/config.sh
echo "[$(date)] 自定义任务执行" >> ~/ark-system/logs/system.log
```

2. 赋予执行权限：

```bash
chmod +x ~/ark-system/cron.d/my-task.sh
```

3. 注册 cron：

```bash
crontab -e
```

添加一行：

```
0 8 * * * /bin/bash ~/ark-system/cron.d/my-task.sh
```

---

## 环境变量参考

所有脚本共享 `config.sh` 中的变量。在你的脚本中加载：

```bash
source ~/ark-system/config.sh
```

可用变量：

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `$FEISHU_WEBHOOK` | 空 | 飞书通知地址 |
| `$SYSTEM_NAME` | ARK | 系统标识 |
| `$LOG_RETENTION_DAYS` | 30 | 日志保留 |
| `$MAX_RETRY` | 3 | 重试次数 |

---

## 常见问题排查

### cron 不执行

```bash
# 检查 cron 是否注册
crontab -l

# macOS 检查 cron 权限
# 系统偏好设置 → 安全性与隐私 → 隐私 → 完全磁盘访问权限 → 添加 /usr/sbin/cron
```

### 脚本找不到

```bash
# 使用绝对路径
0 * * * * /bin/bash /Users/你的用户名/ark-system/cron.d/heartbeat.sh
```

### 飞书通知格式报错

飞书 Webhook 消息体有严格的格式要求。如果飞书返回错误，检查：

- `msg_type` 必须为 `text` 或 `interactive`
- JSON 中不能有换行符出现在字符串外
- `content` 字段内特殊字符需要转义

---

**最后更新：** 2026-07-08
