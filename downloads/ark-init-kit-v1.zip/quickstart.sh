#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# ARK 灌顶包 - 快速启动脚本
# 版本: 1.0.0
# 用途: 一键部署 AI 自动化管道
# ============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

ARK_HOME="$HOME/ark-system"
LOG_DIR="$ARK_HOME/logs"
CRON_DIR="$ARK_HOME/cron.d"
CONFIG_FILE="$ARK_HOME/config.sh"

echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}   ARK 灌顶包 v1.0.0${NC}"
echo -e "${CYAN}   AI 自动化管道一键部署${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

# --------------- 第1步：环境检测 ---------------
echo -e "${YELLOW}[1/5] 环境检测...${NC}"

check_cmd() {
    if command -v "$1" &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} $1 ($($1 --version 2>&1 | head -1))"
        return 0
    else
        echo -e "  ${RED}✗${NC} $1 未安装"
        return 1
    fi
}

PASS=true

echo "  基础工具:"
check_cmd bash    || PASS=false
check_cmd curl    || PASS=false

echo "  运行时:"
check_cmd python3 || PASS=false
check_cmd node    || PASS=false

# Python 版本检查
if command -v python3 &>/dev/null; then
    PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
    PY_MAJOR=$(echo "$PY_VER" | cut -d. -f1)
    PY_MINOR=$(echo "$PY_VER" | cut -d. -f2)
    if [ "$PY_MAJOR" -lt 3 ] || { [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 9 ]; }; then
        echo -e "  ${RED}✗${NC} Python 版本过低: $PY_VER (需要 >= 3.9)"
        PASS=false
    else
        echo -e "  ${GREEN}✓${NC} Python $PY_VER"
    fi
fi

# Node.js 版本检查
if command -v node &>/dev/null; then
    NODE_VER=$(node -v | sed 's/v//')
    NODE_MAJOR=$(echo "$NODE_VER" | cut -d. -f1)
    if [ "$NODE_MAJOR" -lt 20 ]; then
        echo -e "  ${RED}✗${NC} Node.js 版本过低: v$NODE_VER (需要 >= 20)"
        PASS=false
    else
        echo -e "  ${GREEN}✓${NC} Node.js v$NODE_VER"
    fi
fi

if [ "$PASS" = false ]; then
    echo ""
    echo -e "${RED}环境检测未通过，请先安装缺失的工具。${NC}"
    echo "安装指引见 README.md"
    exit 1
fi

echo ""
echo -e "${GREEN}环境检测通过 ✓${NC}"
echo ""

# --------------- 第2步：创建目录结构 ---------------
echo -e "${YELLOW}[2/5] 创建目录结构...${NC}"

mkdir -p "$ARK_HOME"
mkdir -p "$LOG_DIR"
mkdir -p "$CRON_DIR"

echo -e "  ${GREEN}✓${NC} $ARK_HOME"
echo -e "  ${GREEN}✓${NC} $LOG_DIR"
echo -e "  ${GREEN}✓${NC} $CRON_DIR"
echo ""

# --------------- 第3步：生成配置文件 ---------------
echo -e "${YELLOW}[3/5] 生成配置文件...${NC}"

if [ -f "$CONFIG_FILE" ]; then
    echo -e "  ${YELLOW}!${NC} 配置文件已存在，跳过"
else
    cat > "$CONFIG_FILE" << 'CONFEOF'
# ARK 系统配置文件
# 修改以下变量后运行: source ~/ark-system/config.sh

# 飞书机器人 Webhook URL（必填）
FEISHU_WEBHOOK=""

# 心跳间隔（cron 表达式，默认每30分钟）
HEARTBEAT_CRON="*/30 * * * *"

# 日志保留天数
LOG_RETENTION_DAYS=30

# 系统名称（用于通知前缀）
SYSTEM_NAME="ARK"

# 是否开启每日汇总
DAILY_SUMMARY=true

# 每日汇总时间
SUMMARY_HOUR=22
SUMMARY_MINUTE=0

# 重试次数
MAX_RETRY=3
CONFEOF
    echo -e "  ${GREEN}✓${NC} $CONFIG_FILE"
fi
echo ""

# --------------- 第4步：生成心跳脚本 ---------------
echo -e "${YELLOW}[4/5] 生成心跳脚本...${NC}"

HEARTBEAT_SCRIPT="$CRON_DIR/heartbeat.sh"

cat > "$HEARTBEAT_SCRIPT" << 'SCRIPTEOF'
#!/usr/bin/env bash
# ARK 系统心跳检测
# 用途: 检测系统健康状态并通过飞书通知

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ARK_HOME="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="$ARK_HOME/config.sh"
LOG_FILE="$ARK_HOME/logs/system.log"

# 加载配置
if [ -f "$CONFIG_FILE" ]; then
    source "$CONFIG_FILE"
fi

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

send_feishu() {
    local title="$1"
    local content="$2"
    if [ -z "${FEISHU_WEBHOOK:-}" ]; then
        log "飞书 Webhook 未配置，跳过通知"
        return
    fi
    curl -s -X POST "$FEISHU_WEBHOOK" \
        -H "Content-Type: application/json" \
        -d "$(cat <<MSGEOF
{
    "msg_type": "interactive",
    "card": {
        "header": {
            "title": {"tag": "plain_text", "content": "[${SYSTEM_NAME:-ARK}] $title"},
            "template": "$2"
        },
        "elements": [
            {"tag": "div", "text": {"tag": "lark_md", "content": "$content"}}
        ]
    }
}
MSGEOF
)" > /dev/null 2>&1
}

# 健康检查
issues=""
disk_usage=$(df -h / | awk 'NR==2{print $5}' | sed 's/%//')
if [ "$disk_usage" -gt 90 ]; then
    issues="${issues}- 磁盘使用率: ${disk_usage}% (告警)\n"
fi

load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
if command -v python3 &>/dev/null; then
    cpu_cores=$(python3 -c 'import os; print(os.cpu_count() or 1)')
    load_warn=$(echo "$load_avg > $cpu_cores * 0.8" | bc -l 2>/dev/null || echo "0")
else
    cpu_cores=1
    load_warn=0
fi

if [ "$issues" = "" ]; then
    status="正常"
    template="green"
    msg="所有指标正常\n- CPU负载: $load_avg / ${cpu_cores}核\n- 磁盘: ${disk_usage}%"
else
    status="告警"
    template="red"
    msg="$issues\n- CPU负载: $load_avg / ${cpu_cores}核\n- 磁盘: ${disk_usage}%"
fi

log "心跳检测: $status"
send_feishu "心跳检测 - $status" "$msg"
SCRIPTEOF

chmod +x "$HEARTBEAT_SCRIPT"
echo -e "  ${GREEN}✓${NC} $HEARTBEAT_SCRIPT"
echo ""

# --------------- 第5步：注册 cron ---------------
echo -e "${YELLOW}[5/5] 注册 cron 定时任务...${NC}"

CRON_JOB="*/30 * * * * /bin/bash $HEARTBEAT_SCRIPT"

# 检查是否已存在
if crontab -l 2>/dev/null | grep -qF "$HEARTBEAT_SCRIPT"; then
    echo -e "  ${YELLOW}!${NC} cron 任务已存在，跳过"
else
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
    echo -e "  ${GREEN}✓${NC} cron 已注册 (每30分钟)"
fi
echo ""

# --------------- 完成 ---------------
echo -e "${CYAN}========================================${NC}"
echo -e "${GREEN}  ARK 灌顶成功 ✓${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""
echo "  目录:     $ARK_HOME"
echo "  配置:     $CONFIG_FILE"
echo "  日志:     $LOG_DIR"
echo "  心跳:     $HEARTBEAT_SCRIPT"
echo ""
echo -e "${YELLOW}  下一步:${NC}"
echo "  1. 编辑配置:  vim $CONFIG_FILE"
echo "  2. 填入飞书 Webhook URL"
echo "  3. 手动测试:  bash $HEARTBEAT_SCRIPT"
echo "  4. 导入驯养词: 查看 PROMPTS.md"
echo ""
echo -e "${YELLOW}  cron 任务:${NC}"
crontab -l 2>/dev/null | grep ark || echo "  (无)"
echo ""
