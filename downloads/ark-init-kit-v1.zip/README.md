# ARK 灌顶包

¥19.9 一次性工具包。给想搭建自己 AI 自动化系统的人。

---

## 包含什么

| 模块 | 内容 | 文件 |
|------|------|------|
| 自动化管道脚本 | 一键部署的环境检测、定时心跳、飞书通知 | `quickstart.sh` |
| Agent 驯养词模板 | 3套可直接复用的Agent提示词 | `PROMPTS.md` |
| 配置手册 | cron表达式、飞书webhook、日志路径全说明 | `CONFIG.md` |

---

## 30分钟跑通

### 第1步：环境准备（5分钟）

确保你的机器上有：

```bash
# 检查 Python
python3 --version   # 需要 >= 3.9

# 检查 Node.js
node --version      # 需要 >= 20

# 检查 curl
curl --version
```

缺失的工具去官网下载安装即可。

### 第2步：运行快速启动（5分钟）

```bash
cd ~/Downloads
chmod +x quickstart.sh
./quickstart.sh
```

脚本会自动执行：
1. 环境检测
2. 创建目录结构 `~/ark-system/`
3. 生成心跳脚本并注册 cron
4. 输出运行结果

看到 `[ARK] 灌顶成功 ✓` 即完成。

### 第3步：配置通知（5分钟）

打开 `~/ark-system/config.sh`，填入你的飞书机器人 Webhook URL：

```bash
FEISHU_WEBHOOK="https://open.feishu.cn/open-apis/bot/v2/hook/你的token"
```

测试通知：

```bash
bash ~/ark-system/heartbeat.sh
```

飞书收到 `[ARK] 系统心跳正常` 即配置成功。

### 第4步：导入驯养词（10分钟）

打开 `PROMPTS.md`，里面有3套模板：
- **每日巡航 Agent** → 粘贴到你的 Agent 系统提示词
- **内容采集 Agent** → 自动收信息、去重、提炼
- **数据分析 Agent** → 喂数据出结论

每套模板都已调教好，直接粘进去就能用。按你的实际需求改几个关键词就行。

### 第5步：验证全链路（5分钟）

```bash
# 手动触发心跳
bash ~/ark-system/heartbeat.sh

# 查看 cron 是否注册
crontab -l | grep ark

# 查看日志
tail -f ~/ark-system/logs/system.log
```

三项都正常 → 你拥有了一条自动化管道。

---

## 环境要求

| 项目 | 最低版本 |
|------|----------|
| 操作系统 | macOS 12+ 或 Ubuntu 20.04+ |
| Python | 3.9+ |
| Node.js | 20+ |
| Bash | 3.2+ |

Windows 用户建议用 WSL2（Ubuntu）。

---

## 常见问题

**Q: 脚本报 permission denied**
```bash
chmod +x quickstart.sh
```

**Q: cron 心跳没有执行**
检查 crontab 语法：
```bash
crontab -l
```
确保 crond 服务正在运行：
```bash
# macOS
sudo launchctl list | grep cron

# Linux
systemctl status cron
```

**Q: 飞书收不到通知**
- 确认 Webhook URL 完整（以 `hook/v2` 开头）
- 用 curl 直接测试：`curl -X POST "$FEISHU_WEBHOOK" -H "Content-Type: application/json" -d '{"msg_type":"text","content":{"text":"测试"}}'`
- 检查机器是否有外网访问

**Q: 想加更多自动化任务怎么办**
在 `~/ark-system/cron.d/` 目录下放新的脚本，然后在 `crontab -e` 里加一行。格式见 `CONFIG.md`。

**Q: 能部署到服务器上吗**
可以。把 `~/ark-system/` 整个目录 scp 到服务器，重新跑一遍 `quickstart.sh` 即可。

---

## 联系

有问题直接发邮件：
**guanyi2026@agent.qq.com**

附上你的环境信息和报错截图，48小时内回复。
